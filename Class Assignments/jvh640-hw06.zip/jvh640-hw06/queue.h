#ifndef _queue_h
#define _queue_h

int frontelement();
void enq(int data);
int deq();
void empty();
void display();
void create();
int queuesize();

#endif