#include <stdio.h>
#include <stdlib.h>
#include "lib.h"

void create(Tree *tree){
	tree->size = tree->sum =0;
	tree->root = NULL;
}

void insert(Tree *tree, int number){
	Node *temp, *pre, *cur;
	
	tree->size++;
	tree->sum += number;
	temp = (Node *)malloc(sizeof(Node));
	temp->key = number;
	temp->right = temp->left = 0;
	
	if(! tree->root){
		tree->root = temp;
		
	}else{
		cur = tree->root;
		while(cur){
			pre = cur;
			if(number < cur->key){
				cur = cur->left;
			}else{
				cur = cur->right;
			}
		}
		if(number < pre->key){
			pre->left = temp;
		}else{
			pre->right = temp;
		}
	}
}

int find(Tree *tree, int number){
	int found = 0;
	Node *cur;
	cur = tree->root;
	while(cur){
		if(cur->key == number){
			found = 1;
			break;
		}else{
			if(number < cur->key){
				cur = cur->left;
			}else{
				cur = cur->right;
			}
		}
			
	}
	return found;
}

void deleteNode(Node **nodeAdress){
	Node *pre, *cur;
	cur = *nodeAdress;
	if(! (*nodeAdress)->left){
		*nodeAdress = (*nodeAdress)->right;
	}else if(! (*nodeAdress)->right){
		*nodeAdress = (*nodeAdress)->left;
	}else{
		cur = (*nodeAdress)->left;
		if(! cur->right){
			(*nodeAdress)->key = cur->key;
			(*nodeAdress)->left = cur->left;
		}else{
			do{
				pre = cur;
				cur = cur->right;
			}while(cur->right);
			 (*nodeAdress)->key = cur->key;
			 pre->right = cur->left;
		}
		
	}
	free(cur);
}

void del(Tree *tree, int number){
	int found = 0;
	Node *pre, *cur;
	pre = NULL;
	cur = tree->root;
	while(!found && cur){
		pre = cur;
		if(number < cur->key){
			cur = cur->left;
		} else{
			cur = cur->right;
		}
		found = number == cur->key;
	}
	
	if(found){
		tree->size--;
		tree->sum -= number;
		if(! pre){
			deleteNode(& tree->root);
		}else{
			if(number < pre->key){
				deleteNode(& pre->left);
			}else{
				deleteNode(& pre->right);
			}
		}
	}
}

void inorderRec(Node *node){
	if(node){
		inorderRec(node->left);
		printf("%d ", node->key);
		inorderRec(node->right);
	}
}

void inorder(Tree *tree){
	inorderRec(tree->root);
	printf("\n");
}

void preorderRec(Node *node){
	if(node){
		printf("%d \n", node->key);
		preorderRec(node->left);
		preorderRec(node->right);
	}
}

void preorder(Tree *tree){
	preorderRec(tree->root);
}

void postorderRec(Node *node){
	if(node){
		postorderRec(node->left);
		postorderRec(node->right);
		printf("%d ", node->key);
	}
}

void postorder(Tree *tree){
	postorderRec(tree->root);
	printf("\n");
}

void levelorder(Tree *tree){
	Node *temp, *queue[100];
	int size = 0;
	int take = 0;
	if(tree->root){
		queue[size++] = tree->root;
		while(size > take){
			temp = queue[take++];
			printf("%d ", temp->key);
			if(temp->left != NULL){
				queue[size++] = temp->left;
			}
			if(temp->right != NULL){
				queue[size++] = temp->right;
			}
		}
	}
	printf("\n");
}

int max(Tree *tree){
	Node *cur;
	if(tree->root){
		cur = tree->root;
		while(cur->right){
			cur = cur->right;
		}
		return cur->key;
	}
	return 0;
}

int min(Tree *tree){
	Node *cur;
	if(tree->root){
		cur = tree->root;
		while(cur->left){
			cur = cur->left;
		}
		return cur->key;
	}
	return 0;
}

int count(Tree *tree){
	return tree->size;
}

int sum(Tree *tree){
	return tree->sum;
}
int treeHightRec(Node *node){
	if(!node){
		return 0;
	}
	int a = treeHightRec(node->left);
	int b = treeHightRec(node->right);
	return (a > b) ? 1+a : 1+b;
}

int height(Tree *tree){
	return treeHightRec(tree->root);
}
