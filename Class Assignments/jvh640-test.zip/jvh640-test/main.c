#include <stdio.h>
#include <stdlib.h>
#include "lib.h"

int main() {
	Tree tree;
	char ch[17];
	create(&tree);
	printf("Select from the following list:\n");
	printf("insert\n");
	printf("find\n");
	printf("del\n");
	printf("list inorder\n");
	printf("list preoder\n");
	printf("list postorder\n");
	printf("list leverorder\n");
	printf("max\n");
	printf("min\n");
	printf("height\n");
	printf("count\n");
	printf("sum\n");
	printf("quit\n");
	printf("type command as is\n");

	scanf("%s", ch);
	while(ch[0] != 'q'){
		if(ch[0] == 'i'){
			int n;
			scanf("%d", &n);
			insert(&tree, n);
		}else if(ch[0] == 'f'){
			int n;
			scanf("%d", &n);
			if(find(&tree, n)){
				printf("Number found.\n");
			}else{
				printf("Not found!\n");
			}
		}else if(ch[0] == 'd'){
			int n;
			scanf("%d", &n);
			del(&tree, n);
		} else if(ch[0] == 'l'){
			char a[10];
			scanf("%s", a);
			if(a[1] == 'n')
				inorder(&tree);
			if(a[1] == 'r')
				preorder(&tree);
			if(a[1] == 'o')
				postorder(&tree);
			if(a[1] == 'e')
				levelorder(&tree);
		} else if(ch[0] == 'c')
			printf("Number of elements is %d\n", count(&tree));
		else if(ch[0] == 's')
			printf("sum of all elements is %d\n", sum(&tree));
		else if(ch[0] == 'h')
			printf("The hight of the tree is %d\n", height(&tree));
		else if(ch[1] == 'a')
			printf("The maximum of the tree is %d\n", max(&tree));
		else if(ch[1] == 'i')
			printf("The minimum of the tree is %d\n", min(&tree));
		scanf("%s", ch);
	}
    return 0;
}