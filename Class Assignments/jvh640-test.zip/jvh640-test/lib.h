//lib.h is the .h file that contain all the prototypes and struct that will be used in main.c

#ifndef _lib_h
#define _lib_h

typedef struct node{
	int key;
	struct node* right;
	struct node* left;
}Node;

typedef struct tree{
	int size;
	int sum;
	Node *root;
}Tree;

void create(Tree *tree);    //creates the tree dynamically 
void insert(Tree *tree, int number);  //inserts new integers to the tree
int find(Tree *tree, int number);   //find a certain int in the tree
void del(Tree *tree, int number);   //deletes a certain int fro the tree
void inorder(Tree *tree);   //lists the tree in order
void preorder(Tree *tree);  //lists the tree pre odrer 
void postorder(Tree *tree); // lists the tree postorder
void levelorder(Tree *tree);    //lists the tree in level order 
int max(Tree *tree);    // gets the biggest int in the tree
int min(Tree *tree);    //gets the smallest int in the tree
int height(Tree *tree); //gets the height of the tree
int count(Tree *tree);  //gets the count of the tree
int sum(Tree *tree);    //gets the sum of all ints in the tree


#endif
